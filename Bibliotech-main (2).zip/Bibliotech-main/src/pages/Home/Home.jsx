import React, { useState, useEffect } from 'react';
import { getFirestore } from "firebase/firestore";
import {
  MDBContainer,
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBRow,
  MDBCol
} from 'mdb-react-ui-kit';

export function Home() {



  return (
    <MDBContainer className='mt-5'>
      <h3>Visão Geral</h3>
      <div className='square border-top-1'>
        <MDBRow>
          <MDBCol className='sm-3'>
            <MDBCard>
              <MDBCardTitle>Total de Empréstimos</MDBCardTitle>
              <MDBCardBody></MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </div>
    </MDBContainer>
  );

}
